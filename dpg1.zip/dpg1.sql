CREATE DATABASE MKN_Farming_Cooperative;
CREATE TABLE Member(
MemberID int NOT NULL,
MemberName CHAR(50) NOT NULL,
MemberContact INT,
MemberPassword VARCHAR(8) NOT NULL,
MemberResetPass VARCHAR(8),
PRIMARY KEY (MemberID)
);

INSERT INTO Member(MemberID, MemberName, MemberContact, MemberPassword, MemberResetPass)
VALUES(780621001, 'Costa Tau', 081667895, 'uy*******',NULL);
INSERT INTO Member(MemberID, MemberName, MemberContact, MemberPassword, MemberResetPass)
VALUES(571028002, 'Mary Land', 0813541209, '****tau', NULL);
INSERT INTO Member(MemberID, MemberName, MemberContact, MemberPassword, MemberResetPass)
VALUES(830118003, 'Ashy Hiiho', 0815676010,'as******',NULL);
SELECT * FROM Member;

CREATE TABLE Account(
AccNo int NOT NULL PRIMARY KEY,
Accamount DOUBLE,
AccDate DATETIME,
AccStatus VARCHAR(10)
);

INSERT INTO Account(AccNo, Accamount,AccDate, AccStatus)
VALUES(6600771, 80,getDate(), 'Paid');
INSERT INTO Account(AccNo, Accamount,AccDate, AccStatus)
VALUES(7700661,90, getDate(), 'Outstanding');
INSERT INTO Account(AccNo, Accamount, AccDate,AccStatus)
VALUES(8800551,60, getDate(), 'Paid');
SELECT* FROM Account;

CREATE TABLE Customers(
CustomersID int NOT NULL AUTO_INCREMENT,
CustomersNmae VARCHAR(50),
CustomersContacts int,
PRIMARY KEY(CustomersID)
); 
INSERT INTO Customers(CustomersID, CustomersNmae, CustomersContacts)
VALUES ( 1, 'Joe', 0814777543);
INSERT INTO Customers(CustomersID, CustomersNmae, CustomersContacts)
VALUES( 2, 'John', 0812343678);
INSERT INTO Customers(CustomersID, CustomersNmae, CustomersContacts)
VALUES( 3,'Chris', 0819781234);
SELECT* FROM Customers;

CREATE TABLE Suppliers(
Sname CHAR NOT NULL,
Scontacts INT,
Primary key(Sname)
);

INSERT INTO Suppliers(Sname,Scontacts)
VALUES('JJJ Hardware', 061555890);
INSERT INTO Suppliers(Sname, Scontacts)
VALUES('AGRA', 067894136);
INSERT INTO Suppliers(Sname,Scontacts)
VALUES('Kaap Agri',0673336784);
SELECT* FROM Suppliers;

CREATE TABLE Equipments(
EqId int NOT NULL PRIMARY KEY,
EqName VARCHAR(100),
EqPrice DOUBLE,
EqQuantity INT NOT NULL

);
INSERT INTO Equipments(EqId, EqName, EqPrice, EqQuantity)
VALUES(101, 'Tractor', 10000.00, 10);
INSERT INTO Equipments(EqId, EqName, EqPrice, EqQuantity)
VALUES(102, 'housepipe', 120, 30);
INSERT INTO Equipments(EqId, EqName, EqPrice, EqQuantity)
VALUES(103, 'Spade', 80, 70);
SELECT* FROM Equipments;

CREATE TABLE Account_Dashboard(
Accid int NOT NULL PRIMARY KEY,
AccNo int,
MemberID int,
FOREIGN KEY (AccNo) REFERENCES Account(AccNo),
FOREIGN KEY (MemberID) REFERENCES Member(MemberID)
);
ALTER TABLE Account_Dashboard ADD AccDate DATE;
SELECT AccDate=CURDATE() from Account_Dashboard;
SELECT* FROM Account_Dashboard;

CREATE TABLE Sales_Invoice(
Sinvoice INT AUTO_INCREMENT PRIMARY KEY,
CustomersID INT,
EQId INT,
 FOREIGN KEY (CustomersID) REFERENCES Customers(CustomersID),
 FOREIGN KEY (EqId) REFERENCES Equipmetns(EqId),
Qty INT,
price DOUBLE,
total DOUBLE
);
SELECT total=sum(QTY*price)FROM Sales_Invoice;
SELECT * FROM Sales_Invoice;
DROP Table Sales_Invoice;


CREATE TABLE Orders(
OID INT AUTO_INCREMENT PRIMARY KEY,
CustomersNmae VARCHAR(50),
EqName VARCHAR(50),
CustomersID INT,
EQId INT,
 FOREIGN KEY (CustomersID) REFERENCES Customers(CustomersID),
 FOREIGN KEY (EqId) REFERENCES Equipmetns(EqId),
Qty INT,
price DOUBLE,
total DOUBLE
);
SELECT total=sum(QTY*price)FROM Sales_Invoice;
SELECT * FROM Sales_Invoice;

CREATE TABLE Supplier_Invoice(
invoice INT AUTO_INCREMENT PRIMARY KEY,
Sname CHAR,
EqId int,
FOREIGN KEY (EqId) REFERENCES Equipmetns(EqId),
FOREIGN KEY (Sname) REFERENCES Suppliers(Sname),
qty INT,
Price DOUBLE,
Total DOUBLE
);
SELECT Total=sum(qty*Price)FROM Supplier_Invoice;
SELECT*FROM Supplier_Invoice;

SELECT Orders.OID, Customers.CustomersNmae
FROM Orders
INNER JOIN Customers ON Orders.CustomersNmae = Customers.CustomersNmae;

SELECT Supplier_Invoice.invoice, Suppliers.Sname
FROM Supplier_Invoice
INNER JOIN Suppliers ON Supplier_Invoice.Sname = Suppliers.Sname;

SELECT Account_Dashboard.AccNo, Member.MemberID
FROM Account_Dashboard
INNER JOIN Member ON account_dashboard.MemberID = Member.MemberID;

DELIMITER $$
CREATE PROCEDURE GetMembers()
BEGIN
	SELECT 
		MemberID, 
		MemberName, 
		 MemberContact
	FROM
	Member	
	ORDER BY MemberName;    
END$$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE ReStockLevel
( 
IN EqQuantity INT,
OUT StockLevel VARCHAR(10)
)
BEGIN
DECLARE qty INT DEFAULT 0;
    SELECT
        EqQuantity 
    FROM 
        Equipments
    WHERE
		EqQuantity = StockLevel;
	
        IF EqQuantity < 31 THEN
        SET StockLevel = 'Restock';
    END IF;
END$$;
DELIMITER ;
CALL RestockLevel(10,@StockLevel);
SELECT @StockLevel;


DELIMITER $$
CREATE FUNCTION AccLevel(
	Accamount DOUBLE
) 
RETURNS VARCHAR(20)
DETERMINISTIC
BEGIN
    DECLARE MemberStatus VARCHAR(20);

    IF Accamount > 50000 THEN
		SET MemberStatus = 'PLATINUM';
    ELSEIF (Accamount >= 50000 AND 
			Accamount <= 10000) THEN
        SET MemberStatus = 'GOLD';
    ELSEIF  Accamount < 10000 THEN
        SET MemberStatus = 'SILVER';
    END IF;
	-- return the customer level
	RETURN (MemberStatus);
END$$
DELIMITER ;
SELECT 
    MemberName, 
     MemberStatus(AccLevel)
FROM
    Member
ORDER BY 
    MemberName;
    
    
    
DELIMITER //
CREATE PROCEDURE Equipments()
BEGIN
	SELECT *  FROM products;
END //
DELIMITER;
CALL Equipments();


DELIMITER $$
CREATE PROCEDURE GetPayments()
BEGIN
    SELECT 
        customerName, 
        checkNumber, 
        paymentDate, 
        amount
    FROM payments
    INNER JOIN customers 
        using (customerNumber);
END$$

DELIMITER ;

CREATE PROCEDURE GetMemberName(
	IN MemberName VARCHAR(50)
)
BEGIN
	SELECT * 
 	FROM Member
	WHERE MemberName= mName;
END //

DELIMITER ;
CALL GetOfficeByCountry('USA');
DELIMITER $$

CREATE PROCEDURE GetOrderCountByStatus (
	IN  orderStatus VARCHAR(25),
	OUT total INT
)
BEGIN
	SELECT COUNT(orderNumber)
	INTO total
	FROM orders
	WHERE status = orderStatus;
END$$
CALL GetOrderCountByStatus('Shipped',@total);
SELECT @total;
DELIMITER ;

CALL GetMembers();

CREATE TABLE Business_Statement(
BS_iD INT


);